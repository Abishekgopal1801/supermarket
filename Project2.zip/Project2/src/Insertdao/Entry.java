package Insertdao;
import java.util.*;
import bean.Bean_class;
import mainservice.Passingdata;
public class Entry 
{
public static void main(String[] args) 
{
	Scanner sc=new Scanner(System.in);
	Bean_class bcobj=new Bean_class();
	 
	String pname=sc.nextLine();
	int pid=sc.nextInt();
	sc.nextLine();
	String cname=sc.nextLine();
	long cnum=sc.nextLong();
	 
	bcobj.setPname(pname);
	bcobj.setPid(pid);
	bcobj.setCname(cname);
	bcobj.setCnum(cnum);
	int ans=Passingdata.enterdata(bcobj);
	System.out.println(ans);
	sc.close();
}
}
