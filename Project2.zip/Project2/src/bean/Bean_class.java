package bean;

public class Bean_class 
{

private String pname;	
private int pid;
private String cname;
private long cnum;
public String getPname() {
	return pname;
}

public void setPname(String pname) {
	this.pname = pname;
}
public int getPid() {
	return pid;
}

public void setPid(int pid) {
	this.pid = pid;
}

public String getCname() {
	return cname;
}

public void setCname(String cname) {
	this.cname = cname;
}

public long getCnum() {
	return cnum;
}

public void setCnum(long cnum) {
	this.cnum = cnum;
}

public Bean_class()
{
	super();
}

}
