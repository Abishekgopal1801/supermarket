package Update1;
import java.util.*;
import bean.Bean_class;
import Update.Update2;
public class Update3 
{
public static void main(String[] args) 
 {
	String cname;
	int pid;
	Scanner sc=new Scanner(System.in);
	int i=0;
	while(true) {
	System.out.println("Enter the data :"+i);	
	Bean_class bcobj=new Bean_class();
	System.out.println("cname : ");
	System.out.println("pid : ");
	cname=sc.nextLine();
	bcobj.setCname(cname);
	pid=sc.nextInt();
	bcobj.setPid(pid);
	int ans=Update2.enterdata(bcobj);
	System.out.println((ans==i)? "updated":"not updated");
	i++;
	System.out.println("To Quit enter (y)");
	String chk=sc.next();
	if(chk.equals("y")){
		break;
	}
	}
	sc.close();
}
}