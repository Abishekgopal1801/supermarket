package Delete2;
import java.util.*;
import bean.Bean_class;
import Deleting.Delete;
public class Deleting2 
{
public static void main(String[] args) 
 {
	int pid;
	Scanner sc=new Scanner(System.in);
	int i=0;
	while(true) {
	System.out.println("Enter the data :"+i);	
	Bean_class bcobj=new Bean_class();
	System.out.println("pid : ");
	pid=sc.nextInt();
	bcobj.setPid(pid);
	int ans=Delete.enterdata(bcobj);
	System.out.println((ans==i)? "deleted":"not deleted");
	i++;
	System.out.println("To Quit enter (y)");
	String chk=sc.next();
	if(chk.equals("y")){
		break;
	}
	}
	sc.close();
}
}